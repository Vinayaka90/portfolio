after installing this project
- open terminal and go inside this project directory
-  next type npm install
-  after type npm run dev to get the output
